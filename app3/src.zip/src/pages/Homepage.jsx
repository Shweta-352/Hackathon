import React from "react";
import { Link, useNavigate } from "react-router-dom";
import "../pages/Homepage.css";
import Header from "../Components/Header";

function Homepage() {

  return (

    
    <div className="container-fluid">
      <Header/>
      
      <div className="row">

        <div className="ith yenar content "> content content </div>
      </div>
    </div>
  );
}

export default Homepage;
